#include <stdio.h>
#include <stdlib.h>

int main() {
	int _a = 0, _b = 0, _x = 0, _i = 0, _j = 0;

	printf("Enter _a:");
	scanf_s("%d", &_a);
	printf("Enter _b:");
	scanf_s("%d", &_b);
	for (int _i = _a; _i < _b + 1; _i++) {
		printf("%d\n", _i * _i);
	}
	_x = 0;
	for (int _i = 1; _i < _a; _i++) {
		for (int _j = 1; _j < _b; _j++) {
			_x = _x + 1;
		}
	}
	printf("%d\n", _x);
	return 0;
}
