#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "header.h"
#include "LexicalAnalyzer.h"
#include "SyntaxAnalyzer.h"
#include "CodeGenerator.h"

// таблиця лексем
Token * TokenTable;
// кількість лексем
unsigned int TokensNum;

// таблиця ідентифікаторів
Id* IdTable;
// кількість ідентифікаторів
unsigned int IdNum;

unsigned int errors = 0;
char* ErrorsFileName;
FILE* ErrorsFile;

unsigned int IdIdentification(Id IdTable[], Token TokenTable[], unsigned int tokenCount);

int main(int argc, char* argv[])
{
	char InputFile[32] = "";
	FILE* InFile;

	if (argc != 2) {
		printf("p18 to C translator\n~~~~~~~~~~~~~~~~~~~~~~~~\nInput file name: ");
		gets_s(InputFile);
	}
	else {
		strcpy_s(InputFile, argv[1]);
	}

	int i = 0;
	const char format[4] = "p18";
	while (InputFile[i++] != '.');
	for (int j = 0; j < strlen(format);) {
		if (InputFile[i++] != format[j++]) {
			printf("Unknown file format.\n");
			return 1;
		}
	}

	if ((fopen_s(&InFile, InputFile, "rt")) != 0)
	{
		printf("Error: Can not open file: %s\n", InputFile);
		return 1;
	}

	char ErrorFile[32] = "Errors.txt";
	ErrorsFileName = ErrorFile;
	if ((fopen_s(&ErrorsFile, ErrorsFileName, "wt")) != 0)
	{
		printf("Error: Can not create file: %s\n", ErrorsFileName);
		return 0;
	}
	else fclose(ErrorsFile);

	// таблиця лесем
	TokenTable = new Token[MAX_TOKENS];

	// таблиця ідентифікаторів
	IdTable = new Id[MAX_IDENTIFIER_COUNT];

	TokensNum = GetTokens(InFile, TokenTable);
	fclose(InFile);

	if (errors == 0) {
		char TokenFile[32];
		i = 0;
		while (InputFile[i] != '.')
		{
			TokenFile[i] = InputFile[i];
			i++;
		}
		TokenFile[i] = '\0';
		strcat_s(TokenFile, ".token");

		PrintTokensToFile(TokenFile, TokenTable, TokensNum);

		if ((fopen_s(&ErrorsFile, ErrorsFileName, "at")) != 0)
		{
			printf("Error: Can not create file: %s\n", ErrorsFileName);
			return 0;
		}

		fprintf(ErrorsFile, "Lexical analysis completed successfully\n");
		printf("\nThe program is lexical correct. List of tokens in the file %s\n", TokenFile);

		fclose(ErrorsFile);

		parser();

		if (errors == 0) {
			printf("\nThe program is syntax correct.\n");

			if ((fopen_s(&ErrorsFile, ErrorsFileName, "at")) != 0)
			{
				printf("Error: Can not create file: %s\n", ErrorsFileName);
				return 0;
			}

			fprintf(ErrorsFile, "\nSyntax analysis completed successfully\n");

			int ids = IdIdentification(IdTable, TokenTable, TokensNum);

			fclose(ErrorsFile);

			if (errors == 0) {
				if ((fopen_s(&ErrorsFile, ErrorsFileName, "at")) != 0)
				{
					printf("Error: Can not create file: %s\n", ErrorsFileName);
					return 0;
				}

				fprintf(ErrorsFile, "\nSemantic analysis completed successfully, %d identifier found\n", ids);
				printf("\nThe program is semantic correct. %d identifier found\n", ids);

				fclose(ErrorsFile);

				char OutputFile[32];
				i = 0;
				while (InputFile[i] != '.')
				{
					OutputFile[i] = InputFile[i];
					i++;
				}
				OutputFile[i] = '\0';
				strcat_s(OutputFile, ".c");

				FILE* outFile;
				fopen_s(&outFile, OutputFile, "w");
				if (!outFile)
				{
					printf("Failed to open output file.\n");
					exit(1);
				}

				// генерація вихідного С коду
				generateCCode(outFile);
				printf("\nC code generated to %s\n", OutputFile);
			}
			else {
				printf("The program has semantic errors.\n");
			}
		}
		else {
			printf("The program has syntax errors.\n");
		}
	}
	else {
		printf("The program has lexical errors.\n");
	}

	delete[]TokenTable;
	delete[]IdTable;

	if (argc != 2) system("pause");
	return 0;
}

// функція записує оголошені ідентифікатори в таблицю ідентифікаторів IdTable
// повертає кількість ідентифікаторів
// перевіряє чи усі використані ідентифікатори оголошені
unsigned int IdIdentification(Id IdTable[], Token TokenTable[], unsigned int tokenCount)
{
	unsigned int idCount = 0;
	unsigned int i = 0;

	while (TokenTable[i++].type != Variable);

	if (TokenTable[i++].type == Type)
	{
		while (TokenTable[i].type != Semicolon)
		{
			if (TokenTable[i].type == Identifier)
			{
				int yes = 0;
				for (unsigned int j = 0; j < idCount; j++)
				{
					if (!strcmp(TokenTable[i].name, IdTable[j].name))
					{
						yes = 1;
						break;
					}
				}
				if (yes == 1)
				{
					yes = 0;
					printf("Identifier '%s' is already declared!\n", TokenTable[i].name);
					fprintf(ErrorsFile, "Identifier '%s' is already declared!\n", TokenTable[i].name);
					errors++;
					idCount--;
				}


				if (idCount < MAX_IDENTIFIER_COUNT)
				{
					strcpy_s(IdTable[idCount++].name, TokenTable[i++].name);
				}
				else
				{
					printf("Too many identifiers!\n");
					fprintf(ErrorsFile, "Too many identifiers!\n");
				}
			}
			else
				i++;
		}
	}

	for (; i < tokenCount; i++)
	{
		if (TokenTable[i].type == Identifier && TokenTable[i - 1].type != Goto)
		{
			int yes = 0;
			for (unsigned int j = 0; j < idCount; j++)
			{
				if (!strcmp(TokenTable[i].name, IdTable[j].name))
				{
					yes = 1;
					break;
				}
			}
			if (yes == 0) {
				printf("In line %d, an undeclared identifier '%s'!\n", TokenTable[i].line, TokenTable[i].name);
				fprintf(ErrorsFile, "In line %d, an undeclared identifier '%s'!\n", TokenTable[i].line, TokenTable[i].name);
				errors++;
			}
		}

	}

	return idCount; // Повертає кількість ідентифікаторів
}
