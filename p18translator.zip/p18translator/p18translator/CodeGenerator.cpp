#include "CodeGenerator.h"

static int pos = 3;
static int offset = 0;
// набір функцій для рекурсивного спуску 
// на кожне правило - окрема функція

void writeOffset(FILE* outFile);

void variable_declaration(FILE* outFile);
void variable_list(FILE* outFile);
void program_body(FILE* outFile);
void statement(FILE* outFile);
void assignment(FILE* outFile);
void label(FILE* outFile);
void arithmetic_expression(FILE* outFile);
void term(FILE* outFile);
void factor(FILE* outFile);
void input(FILE* outFile);
void output(FILE* outFile);
void conditional(FILE* outFile);
void logical_expression(FILE* outFile);
void and_expression(FILE* outFile);
void comparison(FILE* outFile);
void for_statement(FILE* outFile);
void forTo_statement(FILE* outFile);
void forDownTo_statement(FILE* outFile);
void while_statement(FILE* outFile);
void repeat_statement(FILE* outFile);
void goto_statement(FILE* outFile);
void compound_statement(FILE* outFile);

//<програма> = ‘StartProgram’ <ідентифікатор> ‘;’ ‘Variable’ <оголошення змінних> ‘;’ <тіло програми> ‘EndBlok’ ';'
void generateCCode(FILE* outFile)
{
    fprintf(outFile, "#include <stdio.h>\n#include <stdlib.h>\n\n");
    fprintf(outFile, "int main() {\n");
    offset++;

    variable_declaration(outFile);

    program_body(outFile);

    writeOffset(outFile);
    fprintf(outFile, "return 0;\n");
    fprintf(outFile, "}\n");
}

void writeOffset(FILE* outFile) {
    for (int i = 0; i < offset; i++)    
        fprintf(outFile, "\t");
}

// <оголошення змінних> = [<тип даних> <список змінних>]
void variable_declaration(FILE* outFile)
{
    if (TokenTable[pos].type == Type)
    {
        writeOffset(outFile);
        fprintf(outFile, "int ");
        pos++;
        variable_list(outFile);
        fprintf(outFile, ";\n\n");
        pos++;
    }
}

// <список змінних> = <ідентифікатор> ['==>' <арифметичний вираз>] { ‘,’ <ідентифікатор> ['==>' <арифметичний вираз>]}
void variable_list(FILE* outFile)
{
    fprintf(outFile, TokenTable[pos++].name);

    if (TokenTable[pos].type == Assign) {
        fprintf(outFile, " = ");
        pos++;
        arithmetic_expression(outFile);
    }
    else 
        fprintf(outFile, " = 0");

    while (TokenTable[pos].type == Comma)
    {
        fprintf(outFile, ", ");
        pos++;

        fprintf(outFile, TokenTable[pos++].name);
        if (TokenTable[pos].type == Assign) {
            fprintf(outFile, " = ");
            pos++;
            arithmetic_expression(outFile);
        }
        else
            fprintf(outFile, " = 0");
    }
}

// <тіло програми> = { <оператор> }
void program_body(FILE* outFile)
{
    do
    {
        statement(outFile);
    } while (TokenTable[pos].type != End);
}

// <оператор> = <присвоєння> | <ввід> | <вивід> | <умовний оператор> | <умовний перехід> | <мітка> | <оператор циклу> | <складений оператор>
void statement(FILE* outFile)
{
    writeOffset(outFile);
    switch (TokenTable[pos].type)
    {
    case Input: input(outFile); break;
    case Output: output(outFile); break;
    case If: conditional(outFile); break;
    case Goto: goto_statement(outFile); break;
    case For: for_statement(outFile); break;
    case While: while_statement(outFile); break;
    case Repeat: repeat_statement(outFile); break;
    case Identifier: assignment(outFile); break;
	case Label: label(outFile); break;
    case StartBody: compound_statement(outFile); break;
    default: assignment(outFile);
    }
}

// <присвоєння> = <ідентифікатор> '==>' <арифметичний вираз> ';'
void assignment(FILE* outFile)
{
    fprintf(outFile, TokenTable[pos++].name);
    fprintf(outFile, " = ");
    pos++;
    arithmetic_expression(outFile);
    fprintf(outFile, ";\n");
    pos++;
}

// <мітка> = <ідентифікатор> ':'
void label(FILE* outFile) {
    fprintf(outFile, TokenTable[pos++].name);
    fprintf(outFile, "\n");
}

// <арифметичний вираз> = <доданок> { ‘++’ <доданок> | ‘--’ <доданок> }
void arithmetic_expression(FILE* outFile)
{
    term(outFile);
    while (TokenTable[pos].type == Add || TokenTable[pos].type == Sub)
    {
        if (TokenTable[pos].type == Add)
            fprintf(outFile, " + ");
        else
            fprintf(outFile, " - ");
        pos++;
        term(outFile);
    }
}

// <доданок> = <множник> { ‘**’ <доданок> | ‘Div’ <доданок> | ‘Mod’ <доданок> }
void term(FILE* outFile)
{
    factor(outFile);
    while (TokenTable[pos].type == Mul || TokenTable[pos].type == Div || TokenTable[pos].type == Mod)
    {
        if (TokenTable[pos].type == Mul) {
            fprintf(outFile, " * ");
            pos++;
            factor(outFile);
        }      
        else if (TokenTable[pos].type == Div) {
            fprintf(outFile, " / ");
            fprintf(outFile, "(");
            pos++;
            int denom = pos;
            factor(outFile);
            fprintf(outFile, " == 0 ? (printf(\"Error: Division by zero\\n\"), exit(1), 0) : ");
            pos = denom;
            factor(outFile);
            fprintf(outFile, ")");
        }
        else {
            fprintf(outFile, " %% ");
            fprintf(outFile, "(");
            pos++;
            int denom = pos;
            factor(outFile);
            fprintf(outFile, " == 0 ? (printf(\"Error: Division by zero\\n\"), exit(1), 0) : ");
            pos = denom;
            factor(outFile);
            fprintf(outFile, ")");
        }
        //pos++;
    }
}

// <множник> = <ідентифікатор> | <число> | ‘(’ <арифметичний вираз> ‘)’
void factor(FILE* outFile)
{
    if (TokenTable[pos].type == Identifier)
        fprintf(outFile, TokenTable[pos++].name);
    else if (TokenTable[pos].type == Number)
        fprintf(outFile, "%d", TokenTable[pos++].value);
    else
        if (TokenTable[pos].type == LBraket)
        {
            fprintf(outFile, "(");
            pos++;
            arithmetic_expression(outFile);
            fprintf(outFile, ")");
            pos++;
        }
}

// <ввід> = 'Scan' <ідентифікатор> ';'
void input(FILE* outFile)
{
    pos++;
    fprintf(outFile, "printf(\"Enter ");
    fprintf(outFile, TokenTable[pos].name);
    fprintf(outFile, ":\");\n");
    writeOffset(outFile);
    fprintf(outFile, "scanf_s(\"%%d\", &");
    fprintf(outFile, TokenTable[pos++].name);
    fprintf(outFile, ");\n");
    pos++;
}

// <вивід> = ‘Print’ <арифметичний вираз> ';'
void output(FILE* outFile)
{
    fprintf(outFile, "printf(\"%%d\\n\", ");
    pos++;
    arithmetic_expression(outFile);
    //fprintf(outFile, TokenTable[pos++].name);
    fprintf(outFile, ");\n");
    pos++;
}

// <умовний оператор> ==> 'If' '(' <логічний вираз> ')' <оператор> ['Else' <оператор>]
void conditional(FILE* outFile)
{
    fprintf(outFile, "if ");
    pos++;
    logical_expression(outFile);
    fprintf(outFile, " {\n");

    offset++;
    statement(outFile);
    offset--;

    writeOffset(outFile);
    fprintf(outFile, "}\n");
    if (TokenTable[pos].type == Else)
    {
        pos++;
        writeOffset(outFile);
        fprintf(outFile, "else {\n");

        offset++;
        statement(outFile);
        offset--;

        writeOffset(outFile);
        fprintf(outFile, "}\n");
    }
}

// <логічний вираз> = <вираз І> { ‘Or’ <вираз І> }
void logical_expression(FILE* outFile)
{
    and_expression(outFile);
    while (TokenTable[pos].type == Or)
    {
        fprintf(outFile, " || ");
        pos++;
        and_expression(outFile);
    }
}

// <вираз І> = <порівняння> { ‘And’ <вираз І> }
void and_expression(FILE* outFile)
{
    comparison(outFile);
    while (TokenTable[pos].type == And)
    {
        fprintf(outFile, " && ");
        pos++;
        comparison(outFile);
    }
}

// <порівняння> = <операція порівняння> | ‘Not’ ‘(’ <логічний вираз> ‘)’ | ‘(’ <логічний вираз> ‘)’
// <операція порівняння> = <арифметичний вираз> <менше-більше> <арифметичний вираз>
// <менше-більше> = ‘Eq’ | ‘Neq’ | ‘Ls’ | ‘Gr’
void comparison(FILE* outFile)
{
    if (TokenTable[pos].type == Not)
    {
        // Варіант: ! (<логічний вираз>)
        fprintf(outFile, "!(");
        pos++;
        pos++;
        logical_expression(outFile);
        fprintf(outFile, ")");
        pos++;
    }
    else if (TokenTable[pos].type == LBraket)
    {
        // Варіант: ( <логічний вираз> )
        fprintf(outFile, "(");
        pos++;
        logical_expression(outFile);
        fprintf(outFile, ")");
        pos++;
    }
    else
    {
        // Варіант: <арифметичний вираз> <менше-більше> <арифметичний вираз>
        arithmetic_expression(outFile);
        if (TokenTable[pos].type == Greate || TokenTable[pos].type == Less ||
            TokenTable[pos].type == Equality || TokenTable[pos].type == NotEquality)
        {
            switch (TokenTable[pos].type)
            {
            case Greate: fprintf(outFile, " > "); break;
            case Less: fprintf(outFile, " < "); break;
            case Equality: fprintf(outFile, " == "); break;
            case NotEquality: fprintf(outFile, " != "); break;
            }
            pos++;
            arithmetic_expression(outFile);
        }
    }
}

// <оператор циклу> ==> <оператор циклу forTo> | <оператор циклу forDownTo>
void for_statement(FILE* outFile) {
    fprintf(outFile, "for (int ");
    pos++;
    int iter = pos;
    fprintf(outFile, TokenTable[iter].name);
    fprintf(outFile, " = ");
    pos += 2;
    arithmetic_expression(outFile);
    fprintf(outFile, "; ");
    fprintf(outFile, TokenTable[iter].name);
    if (TokenTable[pos].type == To) {
        fprintf(outFile, " < ");
        pos++;
        arithmetic_expression(outFile);
        fprintf(outFile, "; ");
        fprintf(outFile, TokenTable[iter].name);
        forTo_statement(outFile);
    }
    else {
        fprintf(outFile, " > ");
        pos++;
        arithmetic_expression(outFile);
        fprintf(outFile, "; ");
        fprintf(outFile, TokenTable[iter].name);
        forDownTo_statement(outFile);
    }
}

// <оператор циклу forTo> ==> 'For' <ідентифікатор> '==>' <арифметичний вираз> 'To' <арифметичний вираз> 'Do' <оператор>
void forTo_statement(FILE* outFile) {
    fprintf(outFile, "++) {\n");
    pos++;

    offset++;
    statement(outFile);
    offset--;

    writeOffset(outFile);
    fprintf(outFile, "}\n");
}

// <оператор циклу forDownTo> ==> 'For' <ідентифікатор> '==>' <арифметичний вираз> 'DownTo' <арифметичний вираз> 'Do' <оператор>
void forDownTo_statement(FILE* outFile) {
    fprintf(outFile, "--) {\n");
    pos++;

    offset++;
    statement(outFile);
    offset--;

    writeOffset(outFile);
    fprintf(outFile, "}\n");
}

// <оператор циклу while> ==> 'While' '(' <логічний вираз> ')' 'Do' <оператор>
void while_statement(FILE* outFile) {
    fprintf(outFile, "while ");
    pos++;
    logical_expression(outFile);
    pos++;
    fprintf(outFile, "\n");

    statement(outFile);
}

// <оператор циклу repeat> ==> 'Repeat' <оператор> 'Until' '(' <логічний вираз> ')' ';'
void repeat_statement(FILE* outFile) {
    pos++;
    fprintf(outFile, "do {\n");

    offset++;
    statement(outFile);
    offset--;

    writeOffset(outFile);
    fprintf(outFile, "} while ");
    pos++;
    logical_expression(outFile);
    pos++;
    fprintf(outFile, ";\n");
}

// <умовний перехід> ==> 'Goto' <мітка> ';'
void goto_statement(FILE* outFile) {
    fprintf(outFile, "goto ");
    pos++;
    fprintf(outFile, TokenTable[pos].name);
    fprintf(outFile, ";\n");
    pos+=2;
}

// <складений оператор> = ‘StartBlok’ <тіло програми> ‘EndBlok’ ';'
void compound_statement(FILE* outFile)
{
    fprintf(outFile, "{\n");
    pos++;

    offset++;
    program_body(outFile);
    offset--;

    writeOffset(outFile);
    fprintf(outFile, "}\n");
    pos+=2;
}
