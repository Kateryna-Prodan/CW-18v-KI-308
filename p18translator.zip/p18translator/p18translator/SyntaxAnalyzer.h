#pragma once
#include "stdio.h"
#include "stdlib.h"
#include <string.h>
#include "header.h"

extern unsigned int errors;
extern char* ErrorsFileName;
extern FILE* ErrorsFile;

// Вхідна таблиця лексем
extern Token* TokenTable;
// кількість лексем
extern unsigned int TokensNum;

void parser();
