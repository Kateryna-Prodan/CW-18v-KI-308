#include <stdio.h>
#include <stdlib.h>

int main() {
	int _a = 0, _b = 0, _x = 0, _y = 0;

	printf("Enter _a:");
	scanf_s("%d", &_a);
	printf("Enter _b:");
	scanf_s("%d", &_b);
	printf("%d\n", _a + _b);
	printf("%d\n", _a - _b);
	printf("%d\n", _a * _b);
	printf("%d\n", _a / (_b == 0 ? (printf("Error: Division by zero\n"), exit(1), 0) : _b));
	printf("%d\n", _a % (_b == 0 ? (printf("Error: Division by zero\n"), exit(1), 0) : _b));
	_x = (_a - _b) * 10 + (_a + _b) / (10 == 0 ? (printf("Error: Division by zero\n"), exit(1), 0) : 10);
	_y = _x + _x % (10 == 0 ? (printf("Error: Division by zero\n"), exit(1), 0) : 10);
	printf("%d\n", _x);
	printf("%d\n", _y);
	return 0;
}
