#pragma once
#define MAX_TOKENS 1000
#define MAX_LEXEM_NAME 16
#define MAX_IDENTIFIER_LENGTH 6
#define MAX_IDENTIFIER_COUNT 10

// перерахування, яке описує всі можливі типи лексем
enum TypeOfTokens
{
    StartProgram,   // StartProgram
    StartBody,      // StartBlok
    Variable,		// Variable
    Type,   		// Int32
    End,		    // EndBlok
    Input,			// Scan
    Output,			// Print

    If,				// If
    Else,           // Else
	Goto,			// Goto
    For,			// For
    To,				// To
    DownTo,			// DownTo
	Do,			    // Do
    While,          // While
    Repeat,         // Repeat
    Until,          // Until

	Label,			// Label
    Identifier,	    // Identifier
    Number,		    // Number

    Assign,		    // ==>
    Add,			// ++
    Sub,			// --
    Mul,			// **
    Div,			// Div
    Mod,            // Mod

    Equality,		// Eq
    NotEquality,	// Neq
    Greate,		    // Ls
    Less,			// Gr
    Not,			// Not
    And,			// And
    Or,			    // Or

    LBraket,		// (
    RBraket,		// )
    Semicolon,		// ;
    Comma,			// ,
    Unknown
};

// структура для зберігання інформації про лексему
struct Token
{
    char name[16];      // ім'я лексеми
    int value;          // значення лексеми (для цілих констант)
    int line;           // номер рядка
    TypeOfTokens type;  // тип лексеми
};

// структура для зберігання інформації про ідентифікатор
struct Id
{
    char name[16];
};

// перерахування, яке описує стани лексичного аналізатора
enum States
{
    Start,      // початок виділення чергової лексеми    
    Finish,     // кінець виділення чергової лексеми
	KeyWords,   // опрацювання слів (ключові слова)
    Identifiers,// опрацювання слів (ідентифікатори)
    Digit,      // опрацювання цифри
    Separators, // видалення пробілів, символів табуляції і переходу на новий рядок
    Another,    // опрацювання інших символів
    EndOfFile,  // кінець файлу
    Comment     // видалення коментаря
};