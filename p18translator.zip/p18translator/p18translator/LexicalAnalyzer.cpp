#include "LexicalAnalyzer.h"

// функція отримує лексеми з вхідного файлу F і записує їх у таблицю лексем TokenTable 
// результат функції - кількість лексем
unsigned int GetTokens(FILE* F, Token TokenTable[])
{
	if ((fopen_s(&ErrorsFile, ErrorsFileName, "at")) != 0)
	{
		printf("Error: Can not create file: %s\n", ErrorsFileName);
		return 0;
	}

	States state = Start;
	Token TempToken;
	// кількість лексем
	unsigned int NumberOfTokens = 0;
	char ch, buf[16];
	int line = 1;

	// читання першого символу з файлу 
	ch = getc(F);

	// пошук лексем
	while (1)
	{
		switch (state)
		{
			// стан Start - початок виділення чергової лексеми 
			// якщо поточний символ маленька літера, то переходимо до стану Letter
			// якщо поточний символ цифра, то переходимо до стану Digit
			// якщо поточний символ пробіл, символ табуляції або переходу на новий рядок, то переходимо до стану Separators
			// якщо поточний символ { то є ймовірність, що це коментар, переходимо до стану SComment
			// якщо поточний символ EOF (ознака кінця файлу), то переходимо до стану EndOfFile
			// якщо поточний символ відмінний від попередніх, то переходимо до стану Another
		case Start:
		{
			if (ch == EOF)
				state = EndOfFile;
			else
				if (ch <= 'z' && ch >= 'a' || ch <= 'Z' && ch >= 'A')
					state = KeyWords;
				else
					if (ch == '_')
						state = Identifiers;
					else
						if (ch <= '9' && ch >= '0')
							state = Digit;
						else
							if (ch == ' ' || ch == '\t' || ch == '\n')
								state = Separators;
							else
								if (ch == '{')
									state = Comment;
								else
									state = Another;
			break;
		}

		// стан Finish - кінець виділення чергової лексеми і запис лексеми у таблицю лексем
		case Finish:
		{
			if (NumberOfTokens < MAX_TOKENS)
			{
				if (TempToken.type == Unknown) {
					//Логування лексичних помилок
					printf("Lexical error in line %d. '%s' is unknown.\n", line, TempToken.name);
					fprintf(ErrorsFile, "Lexical error in line %d. '%s' is unknown.\n", line, TempToken.name);
					errors++;
				}

				TokenTable[NumberOfTokens++] = TempToken;
				if (ch != EOF)
					state = Start;
				else
					state = EndOfFile;
			}
			else
			{
				printf("\n\t\t\ttoo many tokens !!!\n");
				fclose(ErrorsFile);
				return NumberOfTokens - 1;
			}
			break;
		}

		// стан EndOfFile - кінець файлу, можна завершувати пошук лексем
		case EndOfFile:
		{
			fclose(ErrorsFile);
			return NumberOfTokens;
		}

		// стан KeyWords - поточний символ - велика літера, поточна лексема - ключове слово
		case KeyWords:
		{
			buf[0] = ch;
			int j = 1;

			ch = getc(F);

			while (((ch <= 'Z' && ch >= 'A') || (ch <= 'z' && ch >= 'a') || (ch <= '9' && ch >= '0')) && j < MAX_LEXEM_NAME - 1)
			{
				buf[j++] = ch;
				ch = getc(F);
			}
			buf[j] = '\0';

			TypeOfTokens temp_type = Unknown;

			if (!strcmp(buf, "StartProgram"))
				temp_type = StartProgram;
			else if (!strcmp(buf, "StartBlok"))
				temp_type = StartBody;
			else if (!strcmp(buf, "Variable"))
				temp_type = Variable;
			else if (!strcmp(buf, "Int32"))
				temp_type = Type;
			else if (!strcmp(buf, "EndBlok"))
				temp_type = End;
			else if (!strcmp(buf, "Scan"))
				temp_type = Input;
			else if (!strcmp(buf, "Print"))
				temp_type = Output;
			else if (!strcmp(buf, "If"))
				temp_type = If;
			else if (!strcmp(buf, "Else"))
				temp_type = Else;
			else if (!strcmp(buf, "Goto"))
				temp_type = Goto;
			else if (!strcmp(buf, "For"))
				temp_type = For;
			else if (!strcmp(buf, "To"))
				temp_type = To;
			else if (!strcmp(buf, "DownTo"))
				temp_type = DownTo;
			else if (!strcmp(buf, "Do"))
				temp_type = Do;
			else if (!strcmp(buf, "While"))
				temp_type = While;
			else if (!strcmp(buf, "Repeat"))
				temp_type = Repeat;
			else if (!strcmp(buf, "Until"))
				temp_type = Until;
			else if (!strcmp(buf, "Div"))
				temp_type = Div;
			else if (!strcmp(buf, "Mod"))
				temp_type = Mod;
			else if (!strcmp(buf, "Eq"))
				temp_type = Equality;
			else if (!strcmp(buf, "Neq"))
				temp_type = NotEquality;
			else if (!strcmp(buf, "Ls"))
				temp_type = Less;
			else if (!strcmp(buf, "Gr"))
				temp_type = Greate;
			else if (!strcmp(buf, "Not"))
				temp_type = Not;
			else if (!strcmp(buf, "And"))
				temp_type = And;
			else if (!strcmp(buf, "Or"))
				temp_type = Or;

			strcpy_s(TempToken.name, buf);
			TempToken.type = temp_type;
			TempToken.value = 0;
			TempToken.line = line;
			state = Finish;
			break;
		}

		// стан Identifiers - поточний символ - символ '_', поточна лексема - ідентифікатор
		case Identifiers:
		{
			ch = getc(F);
			if (ch <= 'Z' && ch >= 'A' || ch <= 'z' && ch >= 'a')
			{
				buf[0] = '_';
				buf[1] = ch;
				int j = 2;

				ch = getc(F);

				TypeOfTokens temp_type = Identifier;
				while (((ch <= 'Z' && ch >= 'A') || (ch <= 'z' && ch >= 'a') || (ch <= '9' && ch >= '0')) && j < MAX_LEXEM_NAME - 1)
				{
					buf[j++] = ch;
					ch = getc(F);
				}
				buf[j] = '\0';

				if (strlen(buf) > MAX_IDENTIFIER_LENGTH)
					temp_type = Unknown;

				if (temp_type == Identifier && ch == ':') {
					temp_type = Label;
					buf[j++] = ch;
					buf[j] = '\0';
					ch = getc(F);
				}
				strcpy_s(TempToken.name, buf);
				TempToken.type = temp_type;
				TempToken.value = 0;
				TempToken.line = line;
				state = Finish;
			}
			else
			{
				strcpy_s(TempToken.name, "_");
				TempToken.type = Unknown;
				TempToken.value = 0;
				TempToken.line = line;
				state = Finish;
			}

			break;
		}

		// стан Digit - поточний символ - цифра, поточна лексема - число
		case Digit:
		{
			buf[0] = ch;
			int j = 1;

			ch = getc(F);

			TypeOfTokens temp_type = Number;
			while (((ch <= 'z' && ch >= 'a') || (ch <= 'Z' && ch >= 'A') || (ch <= '9' && ch >= '0') || ch == '.') && j < MAX_LEXEM_NAME - 1)
			{
				if (ch == '.') {
					ch = getc(F);
					if (ch <= '9' && ch >= '0') {
						fseek(F, ftell(F) - 2, SEEK_SET);
						ch = getc(F);
					}
					else {
						fseek(F, ftell(F) - 2, SEEK_SET);
						ch = getc(F);
						break;
					}
				}

				if (!(ch <= '9' && ch >= '0'))
					temp_type = Unknown;


				buf[j++] = ch;
				ch = getc(F);
			}
			buf[j] = '\0';

			if (strlen(buf) == 1 && !(buf[0] <= '9' && buf[0] >= '0')) {
				if (buf[0] == '-') {
					strcpy_s(TempToken.name, "-");
				}
				else if (buf[0] == '+') {
					strcpy_s(TempToken.name, "+");
				}
				TempToken.type = Unknown;
				TempToken.value = 0;
				TempToken.line = line;
				state = Finish;
			}
			else {
				strcpy_s(TempToken.name, buf);
				TempToken.type = temp_type;
				TempToken.value = temp_type == Unknown ? 0 : atoi(buf);
				TempToken.line = line;
				state = Finish;
			}
			break;
		}

		// стан Separators - поточний символ пробіл, символ табуляції або переходу на новий рядок - видаляємо їх
		case Separators:
		{
			if (ch == '\n')
				line++;

			ch = getc(F);

			state = Start;
			break;
		}

		// стан Comment - поточний символ '{', отже це коментар, видаляємо усі символи до '}'
		case Comment:
		{
			long commentStart = ftell(F);
			int tLine = line;
			while (1)
			{
				ch = getc(F);

				if (ch == EOF)
				{
					fseek(F, commentStart, SEEK_SET);
					line = tLine;

					strcpy_s(TempToken.name, "{");
					TempToken.type = Unknown;
					TempToken.value = 0;
					TempToken.line = line;

					ch = getc(F);
					state = Start;
					break;
				}
				else if (ch == '\n')
				{
					line++;
				}
				else if (ch == '}')
				{
					ch = getc(F);
					state = Start;
					break;
				}
			}
			break;
		}

		// стан Another - поточний символ - символ, відмінний від попередніх
		case Another:
		{
			TempToken.value = 0;
			TempToken.line = line;
			state = Finish;

			if (ch == '+') {
				ch = getc(F);
				if (ch <= '9' && ch >= '0')
				{
					fseek(F, ftell(F) - 2, SEEK_SET);
					ch = getc(F);
					state = Digit;
				}
				else if (ch == '+')
				{
					strcpy_s(TempToken.name, "++");
					TempToken.type = Add;
					ch = getc(F);
				}
				else
				{
					strcpy_s(TempToken.name, "+");
					TempToken.type = Unknown;
				}
			}
			else if (ch == '-') {
				ch = getc(F);
				if (ch <= '9' && ch >= '0')
				{
					fseek(F, ftell(F) - 2, SEEK_SET);
					ch = getc(F);
					state = Digit;
				}
				else if (ch == '-')
				{
					strcpy_s(TempToken.name, "--");
					TempToken.type = Sub;
					ch = getc(F);
				}
				else
				{
					strcpy_s(TempToken.name, "-");
					TempToken.type = Unknown;
				}
			}
			else if (ch == '*') {
				ch = getc(F);
				if (ch == '*')
				{
					strcpy_s(TempToken.name, "**");
					TempToken.type = Mul;
					ch = getc(F);
				}
				else
				{
					strcpy_s(TempToken.name, "*");
					TempToken.type = Unknown;
				}
			}

			else if (ch == '=') {
				ch = getc(F);
				if (ch == '=')
				{
					ch = getc(F);
					if (ch == '>')
					{
						strcpy_s(TempToken.name, "==>");
						TempToken.type = Assign;
						ch = getc(F);
					}
					else
					{
						strcpy_s(TempToken.name, "==");
						TempToken.type = Unknown;
					}
				}
				else
				{
					strcpy_s(TempToken.name, "=");
					TempToken.type = Unknown;
				}
			}

			else if (ch == '(') {
				strcpy_s(TempToken.name, "(");
				TempToken.type = LBraket;
				ch = getc(F);
			}
			else if (ch == ')') {
				strcpy_s(TempToken.name, ")");
				TempToken.type = RBraket;
				ch = getc(F);
			}
			else if (ch == ';') {
				strcpy_s(TempToken.name, ";");
				TempToken.type = Semicolon;
				ch = getc(F);
			}
			else if (ch == ',') {
				strcpy_s(TempToken.name, ",");
				TempToken.type = Comma;
				ch = getc(F);
			}
			else {
				TempToken.name[0] = ch;
				TempToken.name[1] = '\0';
				TempToken.type = Unknown;
				ch = getc(F);
			}
		}
		}
	}
	fclose(ErrorsFile);
}

// функція друкує таблицю лексем на екран
void PrintTokens(Token TokenTable[], unsigned int TokensNum)
{
	char type_tokens[16];
	printf("\n\n---------------------------------------------------------------------------\n");
	printf("|             TOKEN TABLE                                                 |\n");
	printf("---------------------------------------------------------------------------\n");
	printf("| line number |      token      |    value   | token code | type of token |\n");
	printf("---------------------------------------------------------------------------");
	for (unsigned int i = 0; i < TokensNum; i++)
	{
		switch (TokenTable[i].type)
		{
		case StartProgram:
			strcpy_s(type_tokens, "StartProgram");
			break;
		case Variable:
			strcpy_s(type_tokens, "Variable");
			break;
		case Type:
			strcpy_s(type_tokens, "Integer");
			break;
		case Identifier:
			strcpy_s(type_tokens, "Identifier");
			break;
		case Label:
			strcpy_s(type_tokens, "Label");
			break;
		case StartBody:
			strcpy_s(type_tokens, "Start");
			break;
		case End:
			strcpy_s(type_tokens, "End");
			break;
		case Input:
			strcpy_s(type_tokens, "Input");
			break;
		case Output:
			strcpy_s(type_tokens, "Output");
			break;
		case If:
			strcpy_s(type_tokens, "If");
			break;
		case Else:
			strcpy_s(type_tokens, "Else");
			break;
		case Goto:
			strcpy_s(type_tokens, "Goto");
			break;
		case For:
			strcpy_s(type_tokens, "For");
			break;
		case To:
			strcpy_s(type_tokens, "To");
			break;
		case DownTo:
			strcpy_s(type_tokens, "DownTo");
			break;
		case While:
			strcpy_s(type_tokens, "While");
			break;
		case Repeat:
			strcpy_s(type_tokens, "Repeat");
			break;
		case Until:
			strcpy_s(type_tokens, "Until");
			break;
		case Assign:
			strcpy_s(type_tokens, "Assign");
			break;
		case Add:
			strcpy_s(type_tokens, "Add");
			break;
		case Sub:
			strcpy_s(type_tokens, "Sub");
			break;
		case Mul:
			strcpy_s(type_tokens, "Mul");
			break;
		case Div:
			strcpy_s(type_tokens, "Div");
			break;
		case Mod:
			strcpy_s(type_tokens, "Mod");
			break;
		case Equality:
			strcpy_s(type_tokens, "Equality");
			break;
		case NotEquality:
			strcpy_s(type_tokens, "NotEquality");
			break;
		case Greate:
			strcpy_s(type_tokens, "Greate");
			break;
		case Less:
			strcpy_s(type_tokens, "Less");
			break;
		case Not:
			strcpy_s(type_tokens, "Not");
			break;
		case And:
			strcpy_s(type_tokens, "And");
			break;
		case Or:
			strcpy_s(type_tokens, "Or");
			break;
		case LBraket:
			strcpy_s(type_tokens, "LBraket");
			break;
		case RBraket:
			strcpy_s(type_tokens, "RBraket");
			break;
		case Number:
			strcpy_s(type_tokens, "Number");
			break;
		case Semicolon:
			strcpy_s(type_tokens, "Semicolon");
			break;
		case Comma:
			strcpy_s(type_tokens, "Comma");
			break;
		case Unknown:
			strcpy_s(type_tokens, "Unknown");
			break;
		}

		printf("\n|%12d |%16s |%11d |%11d | %-13s |\n",
			TokenTable[i].line,
			TokenTable[i].name,
			TokenTable[i].value,
			TokenTable[i].type,
			type_tokens);
		printf("---------------------------------------------------------------------------");
	}
	printf("\n");
}

// функція друкує таблицю лексем у файл
void PrintTokensToFile(char* FileName, Token TokenTable[], unsigned int TokensNum)
{
	FILE* F;
	if ((fopen_s(&F, FileName, "wt")) != 0)
	{
		printf("Error: Can not create file: %s\n", FileName);
		return;
	}
	char type_tokens[16];
	fprintf(F, "---------------------------------------------------------------------------\n");
	fprintf(F, "|             TOKEN TABLE                                                 |\n");
	fprintf(F, "---------------------------------------------------------------------------\n");
	fprintf(F, "| line number |      token      |    value   | token code | type of token |\n");
	fprintf(F, "---------------------------------------------------------------------------");
	for (unsigned int i = 0; i < TokensNum; i++)
	{
		switch (TokenTable[i].type)
		{
		case StartProgram:
			strcpy_s(type_tokens, "StartProgram");
			break;
		case Variable:
			strcpy_s(type_tokens, "Variable");
			break;
		case Type:
			strcpy_s(type_tokens, "Integer");
			break;
		case Identifier:
			strcpy_s(type_tokens, "Identifier");
			break;
		case Label:
			strcpy_s(type_tokens, "Label");
			break;
		case StartBody:
			strcpy_s(type_tokens, "Start");
			break;
		case End:
			strcpy_s(type_tokens, "End");
			break;
		case Input:
			strcpy_s(type_tokens, "Input");
			break;
		case Output:
			strcpy_s(type_tokens, "Output");
			break;
		case If:
			strcpy_s(type_tokens, "If");
			break;
		case Else:
			strcpy_s(type_tokens, "Else");
			break;
		case Goto:
			strcpy_s(type_tokens, "Goto");
			break;
		case For:
			strcpy_s(type_tokens, "For");
			break;
		case To:
			strcpy_s(type_tokens, "To");
			break;
		case DownTo:
			strcpy_s(type_tokens, "DownTo");
			break;
		case While:
			strcpy_s(type_tokens, "While");
			break;
		case Repeat:
			strcpy_s(type_tokens, "Repeat");
			break;
		case Until:
			strcpy_s(type_tokens, "Until");
			break;
		case Assign:
			strcpy_s(type_tokens, "Assign");
			break;
		case Add:
			strcpy_s(type_tokens, "Add");
			break;
		case Sub:
			strcpy_s(type_tokens, "Sub");
			break;
		case Mul:
			strcpy_s(type_tokens, "Mul");
			break;
		case Div:
			strcpy_s(type_tokens, "Div");
			break;
		case Mod:
			strcpy_s(type_tokens, "Mod");
			break;
		case Equality:
			strcpy_s(type_tokens, "Equality");
			break;
		case NotEquality:
			strcpy_s(type_tokens, "NotEquality");
			break;
		case Greate:
			strcpy_s(type_tokens, "Greate");
			break;
		case Less:
			strcpy_s(type_tokens, "Less");
			break;
		case Not:
			strcpy_s(type_tokens, "Not");
			break;
		case And:
			strcpy_s(type_tokens, "And");
			break;
		case Or:
			strcpy_s(type_tokens, "Or");
			break;
		case LBraket:
			strcpy_s(type_tokens, "LBraket");
			break;
		case RBraket:
			strcpy_s(type_tokens, "RBraket");
			break;
		case Number:
			strcpy_s(type_tokens, "Number");
			break;
		case Semicolon:
			strcpy_s(type_tokens, "Semicolon");
			break;
		case Comma:
			strcpy_s(type_tokens, "Comma");
			break;
		case Unknown:
			strcpy_s(type_tokens, "Unknown");
			break;
		}

		fprintf(F, "\n|%12d |%16s |%11d |%11d | %-13s |\n",
			TokenTable[i].line,
			TokenTable[i].name,
			TokenTable[i].value,
			TokenTable[i].type,
			type_tokens);
		fprintf(F, "---------------------------------------------------------------------------");
	}
	fclose(F);
}
