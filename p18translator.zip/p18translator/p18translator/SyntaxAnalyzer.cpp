#include "SyntaxAnalyzer.h"

unsigned int pos = 0;

void match(TypeOfTokens expectedType);

void program();
void variable_declaration();
void variable_list();
void program_body();
void statement();
void assignment();
void label();
void arithmetic_expression();
void term();
void factor();
void input();
void output();
void conditional();
void logical_expression();
void and_expression();
void comparison();
void for_statement();
void forTo_statement();
void forDownTo_statement();
void while_statement();
void repeat_statement();
void goto_statement();
void compound_statement();

// Переводить тип токена в текстовий варіант
const char* getType(TypeOfTokens tokenType) {
	switch (tokenType)
	{
	case StartProgram:
		return "StartProgram";
		break;

	case StartBody:
		return "StartBlok";
		break;

	case End:
		return "EndBlok";
		break;

	case Variable:
		return "Variable";
		break;

	case Type:
		return "Int32";
		break;

	case Input:
		return "Scan";
		break;

	case Output:
		return "Print";
		break;

	case If:
		return "If";
		break;

	case Else:
		return "Else";
		break;

	case Goto:
		return "Goto";
		break;

	case For:
		return "For";
		break;

	case To:
		return "To";
		break;

	case DownTo:
		return "DownTo";
		break;

	case Do:
		return "Do";
		break;

	case While:
		return "While";
		break;

	case Repeat:
		return "Repeat";
		break;

	case Until:
		return "Until";
		break;

	case Label:
		return "Label";
		break;

	case Identifier:
		return "Identifier";
		break;

	case Number:
		return "Number";
		break;

	case Assign:
		return "==>";
		break;

	case Add:
		return "++";
		break;

	case Sub:
		return "--";
		break;

	case Mul:
		return "**";
		break;

	case Div:
		return "Div";
		break;

	case Mod:
		return "Mod";
		break;

	case Equality:
		return "Eq";
		break;

	case NotEquality:
		return "Neq";
		break;

	case Greate:
		return "Ls";
		break;

	case Less:
		return "Gr";
		break;

	case Not:
		return "Not";
		break;

	case And:
		return "And";
		break;

	case Or:
		return "Or";
		break;

	case LBraket:
		return "(";
		break;

	case RBraket:
		return ")";
		break;

	case Semicolon:
		return ";";
		break;

	case Comma:
		return ",";
		break;

	case Unknown:
		return "Unknown";
		break;

	default:
		return "Undefined";
		break;
	}
}

void parser()
{
	if ((fopen_s(&ErrorsFile, ErrorsFileName, "at")) != 0)
	{
		printf("Error: Can not create file: %s\n", ErrorsFileName);
		return;
	}

	program();

	fclose(ErrorsFile);
}

//Розглянемо рекурсивні процедури, що реалізують синтаксичний аналізатор :
void match(TypeOfTokens expectedType)
{
	if (TokenTable[pos].type != expectedType) {
		const char* type = getType(expectedType);
		if (pos < TokensNum) {
			printf("Syntax error in line %d. Expected '%s'\n", TokenTable[pos].line, type);
			fprintf(ErrorsFile, "Syntax error in line %d. Expected '%s'\n", TokenTable[pos].line, type);
		}
		else {
			printf("Syntax error in line %d. Expected '%s'\n", TokenTable[TokensNum - 1].line + 1, type);
			fprintf(ErrorsFile, "Syntax error in line %d. Expected '%s'\n", TokenTable[TokensNum - 1].line + 1, type);
		}
		errors++;
	}

	pos++;
}

// <програма> = ‘StartProgram’ <ідентифікатор> ‘;’ ‘Variable’ <оголошення змінних> ‘;’ <тіло програми> ‘EndBlok’ ';'
void program()
{
	match(StartProgram);
	match(Semicolon);
	match(Variable);
	variable_declaration();
	match(Semicolon);
	program_body();
	match(End);
	match(Semicolon);
	while (pos < TokensNum) {
		printf("Syntax error in line %d. Statement after end operator.\n", TokenTable[pos].line);
		fprintf(ErrorsFile, "Syntax error in line %d. Statement after end operator.\n", TokenTable[pos].line);
		errors++;
		pos++;
	}
}

// <оголошення змінних> = [<тип даних> <список змінних>]
void variable_declaration()
{
	if (TokenTable[pos].type == Type)
	{
		pos++;
		variable_list();
	}
}

// <список змінних> = <ідентифікатор> ['==>' <арифметичний вираз>] { ‘,’ <ідентифікатор> ['==>' <арифметичний вираз>] }
void variable_list()
{
	match(Identifier);
	if (TokenTable[pos].type == Assign) {
		pos++;
		match(Number);
	}

	while (TokenTable[pos].type == Comma)
	{
		pos++;
		match(Identifier);
		if (TokenTable[pos].type == Assign) {
			pos++;
			match(Number);
		}
	}
}

// <тіло програми> = { <оператор> }
void program_body()
{
	do
	{
		if (pos > TokensNum) break;

		statement();
	} while (TokenTable[pos].type != End);
}

// <оператор> = <присвоєння> | <ввід> | <вивід> | <умовний оператор> | <безумовний перехід> | <мітка> | <оператор циклу forTo> 
// | <оператор циклу forDownTo> | <оператор циклу while> | <оператор циклу repeat> | <складений оператор>
void statement()
{
	switch (TokenTable[pos].type)
	{
	case Input: input(); break;
	case Output: output(); break;
	case If: conditional(); break;
	case Goto: goto_statement(); break;
	case For: for_statement(); break;
	case While: while_statement(); break;
	case Repeat: repeat_statement(); break;	
	case Identifier: assignment(); break;
	case Label: label(); break;
	case StartBody: compound_statement(); break;
	default: {
		if (pos < TokensNum) {
			printf("Syntax error in line %d. Expected statement.\n", TokenTable[pos].line);
			fprintf(ErrorsFile, "Syntax error in line %d. Expected statement.\n", TokenTable[pos].line);
		}
		else {
			printf("Syntax error in line %d. Expected statement.\n", TokenTable[TokensNum - 1].line + 1);
			fprintf(ErrorsFile, "Syntax error in line %d. Expected statement.\n", TokenTable[TokensNum - 1].line + 1);
		}
		errors++;
		pos++;
	}
	}
}

// <присвоєння> = <ідентифікатор> '==>' <арифметичний вираз> ';'
void assignment()
{
	match(Identifier);
	match(Assign);
	arithmetic_expression();
	match(Semicolon);
}

// <мітка> ==> <ідентифікатор> ':'
void label()
{
	match(Label);
}

// <арифметичний вираз> = <доданок> { ‘++’ <доданок> | ‘--’ <доданок> }
void arithmetic_expression()
{
	term();
	while (TokenTable[pos].type == Add || TokenTable[pos].type == Sub)
	{
		pos++;
		term();
	}
}

// <доданок> = <множник> { ‘**’ <доданок> | ‘Div’ <доданок> | ‘Mod’ <доданок> }
void term()
{
	factor();
	while (TokenTable[pos].type == Mul || TokenTable[pos].type == Div || TokenTable[pos].type == Mod)
	{
		pos++;
		factor();
	}
}

// <множник> = <ідентифікатор> | <число> | ‘(’ <арифметичний вираз> ‘)’
void factor()
{
	if (TokenTable[pos].type == Identifier)
	{
		match(Identifier);
	}
	else if (TokenTable[pos].type == Number)
	{
		match(Number);
	}
	else if (TokenTable[pos].type == LBraket)
	{
		match(LBraket);
		arithmetic_expression();
		match(RBraket);
	}
	else
	{
		if (pos < TokensNum) {
			printf("Syntax error in line %d. Expected multiplier\n", TokenTable[pos].line);
			fprintf(ErrorsFile, "Syntax error in line %d. Expected multiplier\n", TokenTable[pos].line);
		}
		else {
			printf("Syntax error in line %d. Expected multiplier\n", TokenTable[TokensNum - 1].line + 1);
			fprintf(ErrorsFile, "Syntax error in line %d. Expected multiplier\n", TokenTable[TokensNum - 1].line + 1);
		}
		errors++;
	}
}

// <ввід> = 'Scan' <ідентифікатор> ';'
void input()
{
	match(Input);
	arithmetic_expression();
	match(Semicolon);
}

// <вивід> = ‘Print’ <арифметичний вираз> ';'
void output()
{
	match(Output);
	arithmetic_expression();
	match(Semicolon);
}

// <умовний оператор> ==> 'If' '(' <логічний вираз> ')' <оператор> ['Else' <оператор>]
void conditional()
{
	match(If);
	match(LBraket);
	logical_expression();
	match(RBraket);
	statement();
	if (TokenTable[pos].type == Else)
	{
		pos++;
		statement();
	}
}

// <логічний вираз> = <вираз І> { ‘Or’ <вираз І> }
void logical_expression()
{
	and_expression();
	while (TokenTable[pos].type == Or)
	{
		pos++;
		and_expression();
	}
}

// <вираз І> = <порівняння> { ‘And’ <вираз І> }
void and_expression()
{
	comparison();
	while (TokenTable[pos].type == And)
	{
		pos++;
		and_expression();
	}
}

// <порівняння> = <операція порівняння> | ‘Not’ ‘(’ <логічний вираз> ‘)’ | ‘(’ <логічний вираз> ‘)’
// <операція порівняння> = <арифметичний вираз> <менше-більше> <арифметичний вираз>
// <менше-більше> = ‘Eq’ | ‘Neq’ | ‘Ls’ | ‘Gr’
void comparison()
{
	if (TokenTable[pos].type == Not)
	{
		// Варіант: Not(<логічний вираз>)
		pos++;
		match(LBraket);
		logical_expression();
		match(RBraket);
	}
	else if (TokenTable[pos].type == LBraket)
	{
		// Варіант: ( <логічний вираз> )
		pos++;
		logical_expression();
		match(RBraket);
	}
	else
	{
		// Варіант: <арифметичний вираз> <менше-більше> <арифметичний вираз>
		arithmetic_expression();
		if (TokenTable[pos].type == Greate || TokenTable[pos].type == Less || TokenTable[pos].type == Equality || TokenTable[pos].type == NotEquality)
		{
			pos++;
			arithmetic_expression();
		}
		else
		{
			if (pos < TokensNum) {
				printf("Syntax error in line %d. Expected comparison operation\n", TokenTable[pos].line);
				fprintf(ErrorsFile, "Syntax error in line %d. Expected comparison operation\n", TokenTable[pos].line);
			}
			else {
				printf("Syntax error in line %d. Expected comparison operation\n", TokenTable[TokensNum - 1].line + 1);
				fprintf(ErrorsFile, "Syntax error in line %d. Expected comparison operation\n", TokenTable[TokensNum - 1].line + 1);
			}
			errors++;
		}
	}
}

// <оператор циклу> ==> <оператор циклу forTo> | <оператор циклу forDownTo>
void for_statement() {
	match(For);
	match(Identifier);
	match(Assign);
	arithmetic_expression();
	if (TokenTable[pos].type == To)
		forTo_statement();
	else
		forDownTo_statement();
}

// <оператор циклу forTo> ==> 'For' <ідентифікатор> '==>' <арифметичний вираз> 'To' <арифметичний вираз> 'Do' <оператор>
void forTo_statement() {
	match(To);
	arithmetic_expression();
	match(Do);
	statement();
}

// <оператор циклу forDownTo> ==> 'For' <ідентифікатор> '==>' <арифметичний вираз> 'DownTo' <арифметичний вираз> 'Do' <оператор>
void forDownTo_statement() {
	match(DownTo);
	arithmetic_expression();
	match(Do);
	statement();
}

// <оператор циклу while> ==> 'While' '(' <логічний вираз> ')' 'Do' <оператор>
void while_statement() {
	match(While);
	match(LBraket);
	logical_expression();
	match(RBraket);
	match(Do);
	statement();
}

// <оператор циклу repeat> ==> 'Repeat' <оператор> 'Until' '(' <логічний вираз> ')' ';'
void repeat_statement() {
	match(Repeat);
	statement();
	match(Until);
	match(LBraket);
	logical_expression();
	match(RBraket);
	match(Semicolon);
}

// <безумовний перехід> ==> 'Goto' <ідентифікатор> ';'
void goto_statement() {
	match(Goto);
	match(Identifier);
	match(Semicolon);
}

// <складений оператор> = ‘StartBlok’ <тіло програми> ‘EndBlok’ ';'
void compound_statement()
{
	match(StartBody);
	program_body();
	match(End);
	match(Semicolon);
}