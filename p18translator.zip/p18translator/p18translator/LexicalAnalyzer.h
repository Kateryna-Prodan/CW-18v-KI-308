#pragma once
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "header.h"

extern unsigned int errors;
extern char* ErrorsFileName;
extern FILE* ErrorsFile;

unsigned int GetTokens(FILE* F, Token TokenTable[]);
void PrintTokens(Token TokenTable[], unsigned int TokensNum);
void PrintTokensToFile(char* FileName, Token TokenTable[], unsigned int TokensNum);
