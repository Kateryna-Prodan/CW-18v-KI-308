#pragma once
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "header.h"

// таблиця лексем
extern Token* TokenTable;
// кількість лексем
extern unsigned int TokensNum;

// таблиця ідентифікаторів
extern Id* IdTable;
// кількість ідентифікаторів
extern unsigned int IdNum;

void generateCCode(FILE* outFile);
