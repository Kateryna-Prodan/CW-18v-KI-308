#include <stdio.h>
#include <stdlib.h>

int main() {
	int _a = 0, _b = 0, _c = 0;

	printf("Enter _a:");
	scanf_s("%d", &_a);
	printf("Enter _b:");
	scanf_s("%d", &_b);
	printf("Enter _c:");
	scanf_s("%d", &_c);
	if (_a > _b) {
		if (_a > _b) {
			printf("%d\n", _a);
		}
		else {
			printf("%d\n", _c);
		}
	}
	else {
		if (_b > _c) {
			printf("%d\n", _b);
		}
		else {
			printf("%d\n", _c);
		}
	}
	if ((_a == _b) && (_a == _c) && (_b == _c)) {
		printf("%d\n", 1);
	}
	else {
		printf("%d\n", 0);
	}
	if ((_a < 0) || (_b < 0) || (_c < 0)) {
		printf("%d\n", -1);
	}
	else {
		printf("%d\n", 0);
	}
	if (!(_a < (_b + _c))) {
		printf("%d\n", 10);
	}
	else {
		printf("%d\n", 0);
	}
	return 0;
}
